package rattco.messages;

public class DamageMessage {

	private int damages;

	public DamageMessage() {
	}

	public DamageMessage(int d) {
		damages = d;
	}

	public int getDamages() {
		return damages;
	}

}
